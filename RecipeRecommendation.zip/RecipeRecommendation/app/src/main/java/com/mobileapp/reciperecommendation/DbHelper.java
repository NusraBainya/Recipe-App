package com.mobileapp.reciperecommendation;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.mobileapp.reciperecommendation.models.Comment;
import com.mobileapp.reciperecommendation.models.Recipe;
import com.mobileapp.reciperecommendation.models.TableContainer;
import com.mobileapp.reciperecommendation.models.User;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "recipes.db";

    private static final String SQL_CREATE_RECIPE =
            "CREATE TABLE " + TableContainer.Recipe.TABLE_NAME + " (" +
                    TableContainer.Recipe._ID + " INTEGER PRIMARY KEY," +
                    TableContainer.Recipe.COLUMN_NAME_TITLE + " TEXT," +
                    TableContainer.Recipe.COLUMN_NAME_INSTRUCTIONS + " TEXT," +
                    TableContainer.Recipe.COLUMN_NAME_INGREDIENTS + " TEXT," +
                    TableContainer.Recipe.COLUMN_NAME_TYPE + " TEXT," +
                    TableContainer.Recipe.COLUMN_NAME_CALORIES + " TEXT," +
                    TableContainer.Recipe.COLUMN_NAME_RATINGS + " TEXT," +
                    TableContainer.Recipe.COLUMN_NAME_IMAGE + " BLOB)";

    private static final String SQL_CREATE_USER =
            "CREATE TABLE " + TableContainer.User.TABLE_NAME + " (" +
                    TableContainer.User._ID + " INTEGER PRIMARY KEY," +
                    TableContainer.User.COLUMN_NAME_USERNAME + " TEXT," +
                    TableContainer.User.COLUMN_NAME_PASSWORD + " TEXT)";

    private static final String SQL_CREATE_COMMENT =
            "CREATE TABLE " + TableContainer.Comment.TABLE_NAME + " (" +
                    TableContainer.Comment._ID + " INTEGER PRIMARY KEY," +
                    TableContainer.Comment.COLUMN_NAME_RECIPE_ID + " TEXT," +
                    TableContainer.Comment.COLUMN_NAME_COMMENT + " TEXT)";

    private static final String SQL_DELETE_RECIPE =
            "DROP TABLE IF EXISTS " + TableContainer.Recipe.TABLE_NAME;

    private static final String SQL_DELETE_USER =
            "DROP TABLE IF EXISTS " + TableContainer.User.TABLE_NAME;

    private static final String SQL_DELETE_COMMENT =
            "DROP TABLE IF EXISTS " + TableContainer.Comment.TABLE_NAME;

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_RECIPE);
        db.execSQL(SQL_CREATE_USER);
        db.execSQL(SQL_CREATE_COMMENT);

    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_RECIPE);
        db.execSQL(SQL_DELETE_USER);
        db.execSQL(SQL_DELETE_COMMENT);

        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }


    public long addRecipe(DbHelper dbHelper, Recipe recipe){
        // Gets the data repository in write mode
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TableContainer.Recipe.COLUMN_NAME_TITLE, recipe.title);
        values.put(TableContainer.Recipe.COLUMN_NAME_INSTRUCTIONS, recipe.instruction);
        values.put(TableContainer.Recipe.COLUMN_NAME_INGREDIENTS, recipe.ingredients);
        values.put(TableContainer.Recipe.COLUMN_NAME_TYPE, recipe.type);
        values.put(TableContainer.Recipe.COLUMN_NAME_CALORIES, recipe.calories);
        values.put(TableContainer.Recipe.COLUMN_NAME_IMAGE, recipe.image);


        // Insert the new row, returning the primary key value of the new row
        return db.insert(TableContainer.Recipe.TABLE_NAME, null, values);
    }

    public List<Recipe> getAllRecipes(DbHelper dbHelper){
        SQLiteDatabase db = dbHelper.getReadableDatabase();


        Cursor cursor = db.query(
                TableContainer.Recipe.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order
        );

        List<Recipe> recipes = new ArrayList<>();
        while(cursor.moveToNext()) {
            long itemId = cursor.getLong(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe._ID));
            String title = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_TITLE));
            String instructions = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_INSTRUCTIONS));
            String ingredients = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_INGREDIENTS));
            String type = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_TYPE));
            String calories = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_CALORIES));
            byte[] image = cursor.getBlob(
                    cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_IMAGE));
            recipes.add(new Recipe(itemId, image, title, instructions, ingredients, type, calories));
        }
        cursor.close();

        return recipes;
    }


    public long addUser(DbHelper dbHelper, User user){
        // Gets the data repository in write mode
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TableContainer.User.COLUMN_NAME_USERNAME, user.username);
        values.put(TableContainer.User.COLUMN_NAME_PASSWORD, user.password);


        // Insert the new row, returning the primary key value of the new row
        return db.insert(TableContainer.User.TABLE_NAME, null, values);
    }

    public Recipe getRecipe(DbHelper dbHelper, long id){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM recipes WHERE _id = " + id, null);
        cursor.moveToFirst();
        long itemId = cursor.getLong(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe._ID));
        String title = cursor.getString(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_TITLE));
        String instructions = cursor.getString(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_INSTRUCTIONS));
        String ingredients = cursor.getString(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_INGREDIENTS));
        String type = cursor.getString(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_TYPE));
        String calories = cursor.getString(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_CALORIES));
        byte[] image = cursor.getBlob(
                cursor.getColumnIndexOrThrow(TableContainer.Recipe.COLUMN_NAME_IMAGE));
        return new Recipe(itemId, image, title, instructions, ingredients, type, calories);
    }

    public List<User> getAllUsers(DbHelper dbHelper) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();


        Cursor cursor = db.query(
                TableContainer.User.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order
        );

        List<User> users = new ArrayList<>();
        while(cursor.moveToNext()) {
            String username = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.User.COLUMN_NAME_USERNAME));
            String password = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.User.COLUMN_NAME_PASSWORD));
            users.add(new User(username,password));
        }
        cursor.close();

        return users;
    }


    public long addComment(DbHelper dbHelper, Comment comment){
        // Gets the data repository in write mode
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TableContainer.Comment.COLUMN_NAME_RECIPE_ID, comment.recipeId);
        values.put(TableContainer.Comment.COLUMN_NAME_COMMENT, comment.comment);


        // Insert the new row, returning the primary key value of the new row
        return db.insert(TableContainer.Comment.TABLE_NAME, null, values);
    }

    public List<Comment> getAllComments(DbHelper dbHelper) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();


        Cursor cursor = db.query(
                TableContainer.Comment.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order
        );

        List<Comment> comments = new ArrayList<>();
        while(cursor.moveToNext()) {
            String recipeId = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Comment.COLUMN_NAME_RECIPE_ID));
            String comment = cursor.getString(
                    cursor.getColumnIndexOrThrow(TableContainer.Comment.COLUMN_NAME_COMMENT));
            comments.add(new Comment(recipeId,comment));
        }
        cursor.close();

        return comments;
    }


}