package com.mobileapp.reciperecommendation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.mobileapp.reciperecommendation.models.Recipe;
import com.mobileapp.reciperecommendation.utils.Utils;

import java.io.IOException;

public class AddActivity extends AppCompatActivity {


    public Button imgBtn, addBtn;
    public EditText titleEt, instructionEt, ingredientsEt, typeEt, caloriesEt;
    public ImageView recipeIv;
    public Bitmap selectedImage;

    //Permissions to read images from gallery
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //Button to upload picture and add recipe in the database
        imgBtn = findViewById(R.id.add_btn_img);
        addBtn = findViewById(R.id.add_btn_add);

        //Inputs in the Add recipe screens
        titleEt = findViewById(R.id.add_et_title);
        instructionEt = findViewById(R.id.add_et_instructions);
        ingredientsEt = findViewById(R.id.add_et_ingredients);
        typeEt = findViewById(R.id.add_et_type);
        caloriesEt = findViewById(R.id.add_et_calorries);
        recipeIv = findViewById(R.id.add_iv_img);

        //Image to select
        imgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Build.VERSION.SDK_INT >= 23){
                    //Checking permissions
                    if (checkPermission())
                    {
                        //Opening image picker
                        openImagePicker();
                    } else {
                        //Requesting permissions
                        requestPermission(); // Code for permission
                    }
                }
                else {
                    //Opening image picker
                    openImagePicker();
                }


            }
        });

        //Adding recipe in the database
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Utils.isEmpty(titleEt) ||
                Utils.isEmpty(instructionEt) ||
                Utils.isEmpty(ingredientsEt) ||
                Utils.isEmpty(typeEt) ||
                Utils.isEmpty(caloriesEt)){
                    Utils.showToast(AddActivity.this, "Some fields are empty");
                }else if(selectedImage==null){
                    Utils.showToast(AddActivity.this, "Select recipe Image please");
                }else{
                    DbHelper dbHelper = new DbHelper(AddActivity.this);
                    long id = dbHelper.addRecipe(dbHelper, new Recipe(0,Utils.getBytes(selectedImage), titleEt.getText().toString(),
                            instructionEt.getText().toString(), ingredientsEt.getText().toString(),
                            typeEt.getText().toString(), caloriesEt.getText().toString()));
                    if(id>0){
                        Utils.showToast(AddActivity.this, "Recipe Added successfully");
                    }else{
                        Utils.showToast(AddActivity.this, "Error in adding recipe");
                    }
                }
            }
        });

    }

    //Checking if permissions granted or not
    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(AddActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    //Requesting permissions
    private void requestPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(AddActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Toast.makeText(AddActivity.this, "Write External Storage permission allows us to get images. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(AddActivity.this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }
    }

    // permissions results
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openImagePicker();
                } else {
                    Utils.showToast(AddActivity.this, "Allow permissions to add Recipe Image");
                }
                break;
        }
    }

    //Opening gallery to select recipe picture
    public void openImagePicker(){
        // permission has been granted, continue as usual
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        // Start the Intent
        startActivityForResult(galleryIntent, 123);
    }

    //When image selected by user
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 123:

                if (resultCode == Activity.RESULT_OK) {
                    //pick image from gallery
                    try {
                        selectedImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                    } catch (IOException e) {
                        Utils.showToast(AddActivity.this, e.getLocalizedMessage());
                        e.printStackTrace();
                    }

                    recipeIv.setImageURI(data.getData());
                }
                break;
        }
    }


}