package com.mobileapp.reciperecommendation.models;

public class Comment {
    public String recipeId, comment;

    public Comment(String recipeId, String comment) {
        this.recipeId = recipeId;
        this.comment = comment;
    }

    public Comment() {

    }
}
