package com.mobileapp.reciperecommendation.models;

public class Recipe {
    public long id;
    public byte[] image;
    public String title, instruction, ingredients, type, calories;

    public Recipe(long id, byte[] image, String title, String instruction, String ingredients, String type, String calories) {
        this.id = id;
        this.image = image;
        this.title = title;
        this.instruction = instruction;
        this.ingredients = ingredients;
        this.type = type;
        this.calories = calories;
    }

    public Recipe() {

    }
}
