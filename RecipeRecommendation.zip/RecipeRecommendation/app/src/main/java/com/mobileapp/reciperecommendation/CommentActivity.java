package com.mobileapp.reciperecommendation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.mobileapp.reciperecommendation.models.Comment;

import java.util.ArrayList;
import java.util.List;

public class CommentActivity extends AppCompatActivity {

    String recipeid = "";
    List<Comment> comments = new ArrayList<>();
    List<String> commentsText = new ArrayList<>();
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);

        listView = findViewById(R.id.comments_lv_comments);
        recipeid = getIntent().getStringExtra("recipeid");

        //Getting all comments
        DbHelper dbHelper = new DbHelper(CommentActivity.this);
        comments = dbHelper.getAllComments(dbHelper);

        //Filtering comments of the selected recipe
        for(Comment comment: comments){
            if(comment.recipeId.equals(recipeid)){
                commentsText.add(comment.comment);
            }
        }

        //Setting comments in listview
        ArrayAdapter<String> itemsAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, commentsText);
        listView.setAdapter(itemsAdapter);

    }
}