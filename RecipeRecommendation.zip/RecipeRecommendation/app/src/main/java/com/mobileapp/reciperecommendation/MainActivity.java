package com.mobileapp.reciperecommendation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mobileapp.reciperecommendation.models.Recipe;
import com.mobileapp.reciperecommendation.models.User;
import com.mobileapp.reciperecommendation.utils.Utils;

import java.util.List;

public class MainActivity extends AppCompatActivity {


    public boolean isAdmin;
    public Button signinBtn, registerBtn;
    public EditText usernameEt, passwordEt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Button for signin and register
        signinBtn = findViewById(R.id.main_btn_signin);
        registerBtn = findViewById(R.id.main_btn_register);

        //Input fields username and password
        usernameEt = findViewById(R.id.main_et_username);
        passwordEt = findViewById(R.id.main_et_password);

        //Checking if it's admin user
        isAdmin = getIntent().getBooleanExtra("isadmin", false);

        //If admin then hide the register button as admin have fixed credentials
        //username: admin & password: admin
        if(isAdmin){
            registerBtn.setVisibility(View.GONE);
            signinBtn.setText("Admin Signin");
            signinBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //username: admin & password: admin
                    if(usernameEt.getText().toString().equals("admin")
                    && passwordEt.getText().toString().equals("admin")){
                        //Open add recipe screen
                        startActivity(new Intent(MainActivity.this, AddActivity.class));
                    }else{
                        //Show error for invalid credentials
                        Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }else{
            //If not an admin then show the register button
            registerBtn.setVisibility(View.VISIBLE);
            signinBtn.setText("User Signin");
            signinBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(Utils.isEmpty(usernameEt) || Utils.isEmpty(passwordEt)){
                        //If fields are empty
                        Utils.showToast(MainActivity.this, "Some fields are empty");
                    }else{
                        //Getting all users to match credentials
                        DbHelper dbHelper = new DbHelper(MainActivity.this);
                        List<User> users = dbHelper.getAllUsers(dbHelper);
                        boolean isValidUser = false;
                        for(User user: users){
                            if(user.username.equals(usernameEt.getText().toString()) &&
                                    user.password.equals(passwordEt.getText().toString())){
                                //If matched it's means a valid user
                                isValidUser=true;
                            }
                        }

                        if(isValidUser){
                            //If a valid user then open Home Screen
                            startActivity(new Intent(MainActivity.this, UserHomeActivity.class));
                        }else{
                            //Show error for invalid credentials
                            Utils.showToast(MainActivity.this, "Invalid credentials");
                        }
                    }
                }
            });

            //Register user on register button press
            registerBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(Utils.isEmpty(usernameEt) || Utils.isEmpty(passwordEt)){
                        //If fields are empty
                        Utils.showToast(MainActivity.this, "Some fields are empty");
                    }else{
                        //Adding user in the database
                        DbHelper dbHelper = new DbHelper(MainActivity.this);
                        long id = dbHelper.addUser(dbHelper, new User(usernameEt.getText().toString(), passwordEt.getText().toString()));
                        if(id>0){
                            Utils.showToast(MainActivity.this, "User registered successfully");
                            usernameEt.setText("");
                            passwordEt.setText("");
                        }else{
                            Utils.showToast(MainActivity.this, "username taken already");
                        }
                    }
                }
            });
        }


    }

}