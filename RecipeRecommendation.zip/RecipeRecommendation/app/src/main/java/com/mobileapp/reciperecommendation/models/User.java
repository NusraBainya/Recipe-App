package com.mobileapp.reciperecommendation.models;

public class User {
    public String username, password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
    public User() {
    }
}
