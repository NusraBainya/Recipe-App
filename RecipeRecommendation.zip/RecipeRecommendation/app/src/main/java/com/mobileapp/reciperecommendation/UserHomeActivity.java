package com.mobileapp.reciperecommendation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.mobileapp.reciperecommendation.adapters.RecipeAdapter;
import com.mobileapp.reciperecommendation.models.Recipe;
import com.mobileapp.reciperecommendation.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class UserHomeActivity extends AppCompatActivity {

    private ListView recipesLv;
    private Button titleBtn, ingredientsBtn, typeBtn, caloriesBtn;
    private EditText searchEt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        // Construct the data source
        List<Recipe> allRecipes = new ArrayList<Recipe>();
        DbHelper dbHelper = new DbHelper(UserHomeActivity.this);
        allRecipes = dbHelper.getAllRecipes(dbHelper);


        //Binding views with java code
        recipesLv = findViewById(R.id.home_lv_recipes);
        titleBtn = findViewById(R.id.home_btn_title);
        ingredientsBtn = findViewById(R.id.home_btn_items);
        typeBtn = findViewById(R.id.home_btn_type);
        caloriesBtn = findViewById(R.id.home_btn_calories);

        searchEt = findViewById(R.id.home_et_search);
        displayRecipes(allRecipes);



        List<Recipe> finalAllRecipes = allRecipes;

        //Filtering the recipes on the basis of title
        titleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Utils.isEmpty(searchEt)){
                    Utils.showToast(UserHomeActivity.this, "Enter search text first");
                }else{
                    List<Recipe> filteredRecipes = new ArrayList<Recipe>();
                    for(Recipe recipe: finalAllRecipes){
                        if( Pattern.compile(Pattern.quote(searchEt.getText().toString()),
                                Pattern.CASE_INSENSITIVE).matcher(recipe.title).find()){
                            filteredRecipes.add(recipe);
                        }
                    }
                    //Displaying recipes in listview
                    displayRecipes(filteredRecipes);
                }
            }
        });

        //Filtering the recipes on the basis of ingredients
        ingredientsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Utils.isEmpty(searchEt)){
                    Utils.showToast(UserHomeActivity.this, "Enter search text first");
                }else{
                    List<Recipe> filteredRecipes = new ArrayList<Recipe>();
                    for(Recipe recipe: finalAllRecipes){
                        if( Pattern.compile(Pattern.quote(searchEt.getText().toString()),
                                Pattern.CASE_INSENSITIVE).matcher(recipe.ingredients).find()){
                            filteredRecipes.add(recipe);
                        }
                    }
                    //Displaying recipes in listview
                    displayRecipes(filteredRecipes);
                }
            }
        });

        //Filtering the recipes on the basis of types such as (Asian, Italian, American, etc)
        typeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Utils.isEmpty(searchEt)){
                    Utils.showToast(UserHomeActivity.this, "Enter search text first");
                }else{
                    List<Recipe> filteredRecipes = new ArrayList<Recipe>();
                    for(Recipe recipe: finalAllRecipes){
                        if( Pattern.compile(Pattern.quote(searchEt.getText().toString()),
                                Pattern.CASE_INSENSITIVE).matcher(recipe.type).find()){
                            filteredRecipes.add(recipe);
                        }
                    }
                    //Displaying recipes in listview
                    displayRecipes(filteredRecipes);
                }
            }
        });

        //Filtering the recipes on the basis of calories. recipes with less than required calories will be displayed
        caloriesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Utils.isEmpty(searchEt)){
                    Utils.showToast(UserHomeActivity.this, "Enter search text first");
                }else{
                    List<Recipe> filteredRecipes = new ArrayList<Recipe>();
                    for(Recipe recipe: finalAllRecipes){
                        if(Integer.parseInt(searchEt.getText().toString())>=Integer.parseInt(recipe.calories)){
                            filteredRecipes.add(recipe);

                        }
                    }
                    //Displaying recipes in listview
                    displayRecipes(filteredRecipes);
                }
            }
        });





    }

    //Display recipes in the listview
    public void displayRecipes(List<Recipe> recipes){
        recipesLv.invalidateViews();
        // Create the adapter to convert the array to views
        RecipeAdapter recipeAdapter = new RecipeAdapter(this, recipes);
        // Attach the adapter to a ListView
        recipesLv.setAdapter(recipeAdapter);
    }
}