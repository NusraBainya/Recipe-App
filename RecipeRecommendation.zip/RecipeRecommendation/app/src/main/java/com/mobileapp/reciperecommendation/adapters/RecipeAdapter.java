package com.mobileapp.reciperecommendation.adapters;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import com.mobileapp.reciperecommendation.DetailActivity;
import com.mobileapp.reciperecommendation.R;
import com.mobileapp.reciperecommendation.models.Recipe;
import com.mobileapp.reciperecommendation.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class RecipeAdapter extends ArrayAdapter<Recipe> {
    Context context;
    public RecipeAdapter(Context context, List<Recipe> recipes) {
        super(context, 0, recipes);
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Recipe recipe = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.viewholder_recipe, parent, false);
        }


        //Binding with the vieholder views
        TextView titleTv = (TextView) convertView.findViewById(R.id.recipe_vh_tv_title);
        TextView typeTv = (TextView) convertView.findViewById(R.id.recipe_vh_tv_type);
        TextView itemTv = (TextView) convertView.findViewById(R.id.recipe_vh_tv_ingredients);
        TextView caloriesTv = (TextView) convertView.findViewById(R.id.recipe_vh_tv_calories);
        CardView parentCv = convertView.findViewById(R.id.recipe_vh_cv_parent);

        ImageView recipeIv = convertView.findViewById(R.id.recipe_vh_iv_img);

        // Populate the data into the template view using the data object
        titleTv.setText(recipe.title);
        typeTv.setText(recipe.type);
        itemTv.setText(recipe.ingredients);
        caloriesTv.setText("Calories: " + recipe.calories);
        recipeIv.setImageBitmap(Utils.getImage(recipe.image));
        // Return the completed view to render on screen

        //Opening detail screen for selected recipe
        parentCv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("recipeid", recipe.id);
                context.startActivity(intent);
            }
        });
        return convertView;
    }
}