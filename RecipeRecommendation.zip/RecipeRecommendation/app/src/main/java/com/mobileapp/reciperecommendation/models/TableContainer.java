package com.mobileapp.reciperecommendation.models;


import android.provider.BaseColumns;

public final class TableContainer {

    private TableContainer() {}

    public static class Recipe implements BaseColumns {
        public static final String TABLE_NAME = "recipes";
        public static final String COLUMN_NAME_IMAGE = "image";
        public static final String COLUMN_NAME_TITLE = "title";
        public static final String COLUMN_NAME_INSTRUCTIONS = "instructions";
        public static final String COLUMN_NAME_INGREDIENTS = "ingredients";
        public static final String COLUMN_NAME_TYPE = "type";
        public static final String COLUMN_NAME_CALORIES = "calories";
        public static final String COLUMN_NAME_RATINGS = "ratings";

    }


    public static class Comment implements BaseColumns {
        public static final String TABLE_NAME = "comments";
        public static final String COLUMN_NAME_RECIPE_ID = "recipeid";
        public static final String COLUMN_NAME_COMMENT = "comment";

    }

    public static class User implements BaseColumns {
        public static final String TABLE_NAME = "users";
        public static final String COLUMN_NAME_USERNAME = "username";
        public static final String COLUMN_NAME_PASSWORD = "password";

    }
}