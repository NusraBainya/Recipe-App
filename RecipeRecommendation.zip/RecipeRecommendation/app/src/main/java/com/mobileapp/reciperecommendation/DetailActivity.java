package com.mobileapp.reciperecommendation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.mobileapp.reciperecommendation.models.Comment;
import com.mobileapp.reciperecommendation.models.Recipe;
import com.mobileapp.reciperecommendation.utils.Utils;

public class DetailActivity extends AppCompatActivity {

    private long recipeId;
    private TextView titleTv, infoTv;
    private ImageView recipeIv;
    private EditText commentEt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        recipeId = getIntent().getLongExtra("recipeid", 1);
        titleTv = findViewById(R.id.detail_tv_title);
        infoTv = findViewById(R.id.detail_tv_info);
        recipeIv = findViewById(R.id.detail_iv_recipeimg);
        commentEt = findViewById(R.id.detail_et_comment);


        DbHelper dbHelper = new DbHelper(DetailActivity.this);
        Recipe recipe = dbHelper.getRecipe(dbHelper, recipeId);

        titleTv.setText(recipe.title);
        infoTv.setText("INSTRUCTIONS\n" + recipe.instruction +
                "\n\nITEMS\n" + (recipe.ingredients.replace(",","\n")) +
                "\n\nTYPE: " + recipe.type +
                "\n\nCALORIES: " + recipe.calories);

        recipeIv.setImageBitmap(Utils.getImage(recipe.image));

        findViewById(R.id.detail_btn_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Utils.isEmpty(commentEt)){
                    Utils.showToast(DetailActivity.this, "Enter your comment first");
                }else{
                    long id = dbHelper.addComment(dbHelper, new Comment(recipeId+"", commentEt.getText().toString()));
                    if(id>0){
                        Utils.showToast(DetailActivity.this, "Comment Added successfully");
                    }else{
                        Utils.showToast(DetailActivity.this, "Comment not added");
                    }
                }
            }
        });

        findViewById(R.id.detail_btn_allcomments).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DetailActivity.this, CommentActivity.class).putExtra("recipeid", recipeId+""));
            }
        });




    }
}